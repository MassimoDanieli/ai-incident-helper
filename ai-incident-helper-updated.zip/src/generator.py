# generator.py

def generate_postmortem(data, mttr, ttd, ttm):
    pass